let a = true
const b = false
console.log(a,b)
let c = 2
let d = 1
console.log(2===1)

const iAmAStudent = true
const isSpring = false
const javaSciptIsBeauty = true
const constCanBeChanged = false
const letCanBeChanged = true
const nullIsADataType = true
const nullIsAValue = false
const iAmFromGrozny = false