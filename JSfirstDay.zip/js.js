// название игры;
let gameName
// описание игры
let gameDesc
// версия игры;
let gameVersion
// имя основного персонажа игры;
let mainCharacterName
// имя разработчика игры;
let developerName
// язык программирования, на которой написана игра;
let gameLanguageCode
// версия языка программирования, на которой написана игра;
let languageVersion
// название карты, на которой происходят действия игры;
let gameMap
//сайт разработчика игры;
let developerSite
// язык интерфейса;
let interfaceLanguage




