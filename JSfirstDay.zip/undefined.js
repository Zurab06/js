let a = undefined
const b = undefined

console.log(a,b)
let c = a+b