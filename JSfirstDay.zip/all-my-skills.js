let city='grozny'
const age =1996
console.log(age)
let age2 = age + 12
let random = ' `"f"` '