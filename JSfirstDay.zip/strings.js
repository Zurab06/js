const filmName = 'transformers'
console.log(filmName)
const app = 'tiktok'
console.log(app)
const wiki ='https://ru.wikipedia.org/wiki/JavaScript'
console.log(wiki)
const lorem = 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. A incidunt praesentium ullam dignissimos, doloremque veniam cumque ad quam quos, dolor itaque adipisci minus voluptate consequatur vero, velit voluptas ea nam!'
console.log(lorem)