
let myAge = 26
let year=1996
let dateOfBirth=17
let sis = 1
let bro=1
let familyNumber = 4
let priceTransport = 250
let currentYear = 2022
let dollarExchange = 60
let euroExchange = 61
let bitcoin = 22000


let myAge1 = 30
let yea1r=1992
let dateOfBirth1=1
let sis1 = 2
let bro1=2
let familyNumber1 = 2
let priceTransport1 = 251
let currentYear1 = 2021
let dollarExchange1 = 20
let euroExchange1 = 31
let bitcoin1 = 23000
