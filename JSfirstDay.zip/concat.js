let a = 'he'
let b= 'ro'
let c = 'in'
//comment
console.log(a+b+c)